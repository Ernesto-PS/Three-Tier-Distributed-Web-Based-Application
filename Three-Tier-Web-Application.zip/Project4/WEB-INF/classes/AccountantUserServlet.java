import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import com.mysql.cj.jdbc.MysqlDataSource;

public class AccountantUserServlet extends HttpServlet 
{
    private Connection connection;
    ResultSet resultSet;
    CallableStatement callStatement = null;
    String message = "";
    String inBoundCall = "";
    HttpSession session;
    RequestDispatcher requestDispatcher;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException 
    {
        int operationNum = Integer.parseInt(request.getParameter("operationNum"));

        try
        {
            getDBConnection();

            switch (operationNum)
            {
                case 1:
                    inBoundCall = "{call Get_The_Maximum_Status_Of_All_Suppliers()}";
                    break;
                case 2:
                    inBoundCall = "{call Get_The_Sum_Of_All_Parts_Weights()}";
                    break;
                case 3:
                    inBoundCall = "{call Get_The_Total_Number_Of_Shipments()}";
                    break;
                case 4:
                    inBoundCall = "{call Get_The_Name_Of_The_Job_With_The_Most_Workers()}";
                    break;
                case 5:
                    inBoundCall = "{call Get_The_Name_Of_The_Job_With_The_Most_Workers()}";
                    break;
            }

            callStatement = connection.prepareCall(inBoundCall);

            try 
            {
                if (callStatement.execute()) 
                {
                    try 
                    {
                        resultSet = callStatement.getResultSet();
                        message = getHtmlRows(resultSet);
                    } 
                    catch (SQLException sqlException) 
                    {
                        message = String.valueOf("<p style=background-color:red; color: black;>Error executing the SQL statement:<br>" + String.valueOf(sqlException) + "</p>");
                    }
                } 
                else 
                {
                    message = String.valueOf("<p style=background-color:red; color: black;>Error executing the SQL statement:<br></p>");
                }
            } 
            catch (SQLException e) 
            {
                e.printStackTrace();
            }
    
            session = request.getSession();
            session.setAttribute("message", message);
            requestDispatcher = this.getServletContext().getRequestDispatcher("/accountantHome.jsp");
            requestDispatcher.forward(request, response);
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }

    private void getDBConnection()
    {
        Properties properties = new Properties();
        FileInputStream filein = null;
        MysqlDataSource dataSource = null;

        // Read a properties file
        try
        {
            // Load properties from file
            filein = new FileInputStream("C:/Program Files/Apache Software Foundation/Tomcat 11.0/webapps/Project4/WEB-INF/lib/theaccountant.properties");
            properties.load(filein);

            // Establish connection to the database
            dataSource = new MysqlDataSource();
            dataSource.setURL(properties.getProperty("MYSQL_DB_URL"));
            dataSource.setUser(properties.getProperty("MYSQL_DB_USERNAME"));
            dataSource.setPassword(properties.getProperty("MYSQL_DB_PASSWORD"));

            // Establishes connection to the database
            connection = dataSource.getConnection();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        catch(IOException e) 
        {
            e.printStackTrace();
        }
    }

    public static synchronized String getHtmlRows(ResultSet results) throws SQLException 
    {
      StringBuilder htmlRows = new StringBuilder();
      ResultSetMetaData metaData = results.getMetaData();
      int columnCount = metaData.getColumnCount();

      htmlRows.append("<style>");
      htmlRows.append("table {");
      htmlRows.append("width: 40%;");
      htmlRows.append("margin-left: auto;");
      htmlRows.append("margin-right: auto;");
      htmlRows.append("border: 1px solid white;");
      htmlRows.append("border-collapse: collapse;");
      htmlRows.append("}");
      htmlRows.append("th, td {");
      htmlRows.append("border: 1px solid black;");
      htmlRows.append("text-align: center;");
      htmlRows.append("}");
      htmlRows.append("th {");
      htmlRows.append("background-color: red;");
      htmlRows.append("color: black;");
      htmlRows.append("}");
      htmlRows.append("td {");
      htmlRows.append("color: black;");
      htmlRows.append("}");
      htmlRows.append("tr.even td {");
      htmlRows.append("background-color: grey;");
      htmlRows.append("}");
      htmlRows.append("tr.odd td {");
      htmlRows.append("background-color: white;");
      htmlRows.append("}");
      htmlRows.append("</style>");

      htmlRows.append("<table>");
      htmlRows.append("<thead>");
      htmlRows.append("<tr>");

      for(int i = 1; i <= columnCount; ++i) 
      {
         htmlRows.append("<th><b>");
         htmlRows.append(metaData.getColumnName(i));
         htmlRows.append("</b></th>");
      }

      htmlRows.append("</tr>");
      htmlRows.append("</thead>");
      htmlRows.append("<tbody>");

      int rowCount = 0;
      while (results.next()) 
      {
         if (rowCount % 2 == 0) 
         {
            htmlRows.append("<tr class='even'>");
         } 
         else 
         {
            htmlRows.append("<tr class='odd'>");
         }

         rowCount++;

         for(int i = 1; i <= columnCount; ++i) 
         {
            htmlRows.append("<td>");
            htmlRows.append(results.getString(i));
            htmlRows.append("</td>");
         }

         htmlRows.append("</tr>");
      }

      htmlRows.append("</tbody>");
      htmlRows.append("</table>");

      return htmlRows.toString();
    }
}