import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import com.mysql.cj.jdbc.MysqlDataSource;

public class ClientUserServlet extends HttpServlet 
{
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;
    HttpSession session;
    RequestDispatcher requestDispatcher;
    String sqlStatement = "";
    String message = "";
    int rowsAffected;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException 
    {
        sqlStatement = request.getParameter("sqlStatement");

        try 
        {
            getDBConnection();
            statement = connection.createStatement();
            
            if (sqlStatement.toUpperCase().contains("SELECT")) 
            {
                resultSet = statement.executeQuery(sqlStatement);
                message = getHtmlRows(resultSet);
                session = request.getSession();
                session.setAttribute("message", message);
                session.setAttribute("sqlStatement", sqlStatement);
                requestDispatcher = getServletContext().getRequestDispatcher("/clientHome.jsp");
                requestDispatcher.forward(request, response);
            }
            else
            {
                message = String.valueOf("<p style=background-color:red; color: black;>Permission Denied!<br></p>");
                session = request.getSession();
                session.setAttribute("message", message);
                session.setAttribute("sqlStatement", sqlStatement);
                requestDispatcher = getServletContext().getRequestDispatcher("/clientHome.jsp");
                requestDispatcher.forward(request, response);
            }
        }
        catch (SQLException sqlException) 
        {
            message = String.valueOf("<p style=background-color:red; color: black;>Error executing the SQL statement:<br>" + String.valueOf(sqlException) + "</p>");
            session = request.getSession();
            session.setAttribute("message", message);
            session.setAttribute("sqlCommand", sqlStatement);
            requestDispatcher = this.getServletContext().getRequestDispatcher("/clientHome.jsp");
            requestDispatcher.forward(request, response);
        } 
    }

    private void getDBConnection()
    {
        Properties properties = new Properties();
        FileInputStream filein = null;
        MysqlDataSource dataSource = null;

        // Read a properties file
        try
        {
            // Load properties from file
            filein = new FileInputStream("C:/Program Files/Apache Software Foundation/Tomcat 11.0/webapps/Project4/WEB-INF/lib/client.properties");
            properties.load(filein);

            // Establish connection to the database
            dataSource = new MysqlDataSource();
            dataSource.setURL(properties.getProperty("MYSQL_DB_URL"));
            dataSource.setUser(properties.getProperty("MYSQL_DB_USERNAME"));
            dataSource.setPassword(properties.getProperty("MYSQL_DB_PASSWORD"));

            // Establishes connection to the database
            connection = dataSource.getConnection();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        catch(IOException e) 
        {
            e.printStackTrace();
        }
    }
    
    public static synchronized String getHtmlRows(ResultSet results) throws SQLException 
    {
      StringBuilder htmlRows = new StringBuilder();
      ResultSetMetaData metaData = results.getMetaData();
      int columnCount = metaData.getColumnCount();

      htmlRows.append("<style>");
      htmlRows.append("table {");
      htmlRows.append("width: 40%;");
      htmlRows.append("margin-left: auto;");
      htmlRows.append("margin-right: auto;");
      htmlRows.append("border: 1px solid white;");
      htmlRows.append("border-collapse: collapse;");
      htmlRows.append("}");
      htmlRows.append("th, td {");
      htmlRows.append("border: 1px solid black;");
      htmlRows.append("text-align: center;");
      htmlRows.append("}");
      htmlRows.append("th {");
      htmlRows.append("background-color: red;");
      htmlRows.append("color: black;");
      htmlRows.append("}");
      htmlRows.append("td {");
      htmlRows.append("color: black;");
      htmlRows.append("}");
      htmlRows.append("tr.even td {");
      htmlRows.append("background-color: grey;");
      htmlRows.append("}");
      htmlRows.append("tr.odd td {");
      htmlRows.append("background-color: white;");
      htmlRows.append("}");
      htmlRows.append("</style>");

      htmlRows.append("<table>");
      htmlRows.append("<thead>");
      htmlRows.append("<tr>");

      for(int i = 1; i <= columnCount; ++i) 
      {
         htmlRows.append("<th><b>");
         htmlRows.append(metaData.getColumnName(i));
         htmlRows.append("</b></th>");
      }

      htmlRows.append("</tr>");
      htmlRows.append("</thead>");
      htmlRows.append("<tbody>");

      int rowCount = 0;
      while (results.next()) 
      {
         if (rowCount % 2 == 0) 
         {
            htmlRows.append("<tr class='even'>");
         } 
         else 
         {
            htmlRows.append("<tr class='odd'>");
         }

         rowCount++;

         for(int i = 1; i <= columnCount; ++i) 
         {
            htmlRows.append("<td>");
            htmlRows.append(results.getString(i));
            htmlRows.append("</td>");
         }

         htmlRows.append("</tr>");
      }

      htmlRows.append("</tbody>");
      htmlRows.append("</table>");

      return htmlRows.toString();
    }
}