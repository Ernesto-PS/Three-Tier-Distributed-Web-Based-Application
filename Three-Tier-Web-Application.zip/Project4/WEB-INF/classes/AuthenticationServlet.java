import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;
import com.mysql.cj.jdbc.*;


public class AuthenticationServlet extends HttpServlet 
{
    private Connection connection; // Connection object used to connect to MySQL DBMS
    private ResultSet lookupResults; // ResultSet object holds response from search of the usercredentials table
    private PreparedStatement pstatement; // PreparedStatement object

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        String inBoundUserName = request.getParameter("username"); // User submitted username
        String inBoundPassword = request.getParameter("password"); // User submitted password
        String credentialsSearchQuery = "SELECT * FROM usercredentials WHERE login_username = ? AND login_password = ?";
        boolean userCredentialsOK = false;
        
        try 
        {
            // Get a connection to the credentialsDB
            getDBConnection();
            
            // Set the prepare statement object
            pstatement = connection.prepareStatement(credentialsSearchQuery);

            // Set prepared statement parameters
            pstatement.setString(1,  inBoundUserName);
            pstatement.setString(2,  inBoundPassword);

            // Sees if the user entered credentials appear in the usercredentials table in the credentialsDB
            lookupResults = pstatement.executeQuery();
            
            // Checks to see if there is a match on the user credentials, if not, there is a mismatch.
            if (lookupResults.next()) 
            {
                String userNameFromCredentialsDB = lookupResults.getString("login_username");
                String userPasswordFromCredentialsDB = lookupResults.getString("login_password");
                if (userNameFromCredentialsDB.equals(inBoundUserName) && userPasswordFromCredentialsDB.equals(inBoundPassword))
                {
                    userCredentialsOK = true;
                }
            }
            else
            {
                userCredentialsOK = false;
            }
        } 
        catch (SQLException sqlException) 
        {
            JOptionPane.showMessageDialog(null, "Error: SQL Exception", "MAJOR ERROR - ERROR", JOptionPane.ERROR_MESSAGE);
        } 
        
        // Redirects the authenticated user to the correct home page based on who they are. If not, redirect to error page.
        if (userCredentialsOK) 
        {
            if (inBoundUserName.equals("root") && inBoundPassword.equals("Thorcito_1102"))
            {
                response.sendRedirect("/Project4/rootHome.jsp");
            }
            else if (inBoundUserName.equals("client") && inBoundPassword.equals("client"))
            {
                response.sendRedirect("/Project4/clientHome.jsp");
            }
            else if (inBoundUserName.equals("theaccountant") && inBoundPassword.equals("theaccountant"))
            {
                response.sendRedirect("/Project4/accountantHome.jsp");
            }
            else
            {
                response.sendRedirect("/Project4/errorpage.html");
            }
        }
        else
        {
            response.sendRedirect("/Project4/errorpage.html");
        }
    }

    // The getDBConnecyion() method establishes a connection to the credentialsDB database. This method is executed on behalf of a 
    // system-level application with root user privileges.
    private void getDBConnection()
    {
        Properties properties = new Properties();
        FileInputStream filein = null;
        MysqlDataSource dataSource = null;

        // Read a properties file
        try
        {
            // Load properties from file
            filein = new FileInputStream("C:/Program Files/Apache Software Foundation/Tomcat 11.0/webapps/Project4/WEB-INF/lib/systemapp.properties");
            properties.load(filein);

            // Establish connection to the database
            dataSource = new MysqlDataSource();
            dataSource.setURL(properties.getProperty("MYSQL_DB_URL"));
            dataSource.setUser(properties.getProperty("MYSQL_DB_USERNAME"));
            dataSource.setPassword(properties.getProperty("MYSQL_DB_PASSWORD"));

            // Establishes connection to the database
            connection = dataSource.getConnection();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        catch(IOException e) 
        {
            e.printStackTrace();
        }
    }
}